package nga.oop4.updated;

public class Menu {
	public void menu() {
		System.out.println("Press key 1 to show list of employees.");
		System.out.println("Press key 2 to enter list of engineers.");
		System.out.println("Press key 3 to enter list of offciers.");
		System.out.println("Press key 4 to enter list of workers.");
		System.out.println("Press key 5 to find a employee by name. ");
	}
}
