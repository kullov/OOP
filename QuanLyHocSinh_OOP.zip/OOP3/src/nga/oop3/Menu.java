package nga.oop3;

public class Menu {
	public void menu() {
		System.out.println("Press key 1 for show information of the semesters.");
		System.out.println("Press key 2 to find students were born in YOB.");
		System.out.println("Press key 3 to find the number of students were born in YOB and live in HN. ");
	}
}
