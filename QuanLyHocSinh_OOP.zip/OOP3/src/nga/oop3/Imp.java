package nga.oop3;

public interface Imp {

}
